#include "interactive_simulation.h"

using namespace std;
using namespace boost::numeric::odeint;

void odesystem(const std::vector<double> &u, std::vector<double> &dudt, const double t){
    double r = params[0];
    double a = params[1];
    double m = params[2];
    double H = u[0], P = u[1];
    dudt[0] = r*H - a*H*P;
    dudt[1] = a*H*P - m*P;
}

int main(){
    double ti = 0, tf = 50, dt = 0.01;
    params = {0.05,0.005,0.1};
    ODE ode(ti,tf,dt,"results.csv",{"H", "P"},odesystem);
    ode.initializeSolver({50,5});

    for (ode.t = ode.ti + ode.dt; ode.t <= ode.tf; ode.t += ode.dt){
        ode.advanceStep();
        ode.save();
    }
    ode.finishSimulation();

    return 0;
}