#ifndef H_InteractiveSimulation
#define H_InteractiveSimulation

#include <iostream>
#include <fstream> 
#include <vector>
#include <string>
#include <boost/numeric/odeint.hpp>

using namespace std;
using namespace boost::numeric::odeint;

//globals
std::vector<double> params;
bool flag_simulation = false;

typedef struct TODE {    
public:
    double tini, tfinal, dt, t;    
    std::string output_file;
    std::ofstream fp;
    std::vector<std::string> names;
    std::vector<double> u;
    std::function<void (const std::vector<double> &u, std::vector<double> &dudt, const double /* t */)> odeSystem;
    runge_kutta_cash_karp54<std::vector<double>> stepper;
    controlled_runge_kutta< runge_kutta_cash_karp54<std::vector<double>> > c_stepper;
    
    TODE(double ti, double tf, double deltat, std::string out, std::vector<std::string> n,
        std::function<void (const std::vector<double> &u, std::vector<double> &dudt, const double /* t */)> s){
        tini = ti;
        tf = tfinal;
        dt = deltat;
        output_file = out;
        names = n;
        odeSystem = s;        
        fp.open(out);
    }
    ~TODE(){
    }

    std::vector<double> advanceStep(){    
        c_stepper.stepper().do_step(odeSystem, u, t, dt);
        return u;
    }

    void initializeSolver(std::vector<double> values){
        fp << "time";
        for (auto v : names){
            fp << "," << v;
        }
        fp << endl;
        u = values;//initial condition 
        t = tini;
        c_stepper = make_controlled(1.E-08, 1.E-08, stepper);
        save(); //save initial condition
    }

    void save(){
        fp << t;
        for (double v : u){
            fp << "," << (v);
        }
        fp << endl;
    }

    void finishSimulation(){
        fp.close();
        u.clear();
        names.clear();
    }
    
} ODE; 

#endif